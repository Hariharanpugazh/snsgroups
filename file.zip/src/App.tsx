import React from 'react';
import SNSLogo from './components/Logo/SNSLogo';
import Section1 from './components/Section1';
import Footer from './components/footer/footer';
import Header from './components/header/header';
function App() {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4 md:flex-row md:justify-start">
      {/* Circular Logo */}
      
      {/* Header */}
      <div className='mt-8'>
        <Header />
      </div>

      <div className="flex-shrink-0 md:ml-10">
        {/* Large logo for desktop */}
        <div className="hidden md:block">
          <SNSLogo size="400px" />
        </div>

        {/* Medium logo for tablets */}
        <div className="hidden sm:block md:hidden">
          <SNSLogo size="300px" />
        </div>

        {/* Small logo for mobile */}
        <div className="block sm:hidden">
          <SNSLogo size="250px" />
        </div>
      </div>

      {/* Footer */}
      <div className='mt-8'>
        <Footer />
      </div>

      {/* Content Widgets */}
      <div className="flex-grow md:ml-10">
        <Section1 />
      </div>
    </div>
  );
}

export default App;