import React from 'react';
import CircularProgress from './CircularProgress/CircularProgress';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBuilding, faLaptop, faLightbulb, faSchool, faDumbbell } from '@fortawesome/free-solid-svg-icons';

const Section1: React.FC = () => {
  const features = [
    {
      title: 'SNS Venture Capital & Investment',
      description: 'Funding high-potential startups for strategic ownership stakes.',
      icon: faBuilding,
      link: '',
      color: 'bg-red-500',
    },
    {
      title: 'SNS Square Technologies',
      description: 'Driving digital transformation with cutting-edge IT and software solutions.',
      icon: faLaptop,
      link: 'https://www.snssquare.com/',
      color: 'bg-green-500',
    },
    {
      title: 'SNS Innovation Hub',
      description: 'Empowering entrepreneurs with mentorship, resources, and a platform for innovation.',
      icon: faLightbulb,
      link: 'https://snsihub.ai/',
      color: 'bg-pink-500',
    },
    {
      title: 'SNS Institutions',
      description: 'Fostering holistic growth through high-quality education.',
      icon: faSchool,
      link: 'https://main.snsgroups.com/',
      color: 'bg-orange-500',
    },
    {
      title: 'SNS SPINE',
      description: 'Enabling mental and physical well-being through sports, gaming, entertainment, and clubs.',
      icon: faDumbbell,
      link: 'https://snsspine.in/',
      color: 'bg-blue-500',
    },
  ];

  return (
    <div className="flex flex-col md:flex-row items-center justify-center gap-8 min-h-screen p-4">
      {/* Circular Progress */}
      <div className="flex-shrink-0">
        <CircularProgress
          segments={[
            { color: '#FF0000', percentage: 20 },
            { color: '#00FF00', percentage: 20 },
            { color: '#FF00FF', percentage: 20 },
            { color: '#FFA500', percentage: 20 },
            { color: '#0000FF', percentage: 20 },
          ]}
          size="400px"
        />
      </div>

      {/* Widgets */}
      <div className="flex flex-col gap-6">
        {features.map((feature, index) => (
          <div
            key={index}
            className={`flex items-center gap-4 p-4 rounded-lg shadow-md text-white ${feature.color}`}
            onClick={() => feature.link && window.open(feature.link, '_blank')}
          >
            <div className="text-3xl">
              <FontAwesomeIcon icon={feature.icon} />
            </div>
            <div>
              <h3 className="text-xl font-bold">{feature.title}</h3>
              <p className="text-sm">{feature.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Section1;